import { beforeEach, describe, expect, it, vi } from "vitest";
import { parseQuickRollInput } from "../src/module/parser";

declare global {
  // eslint-disable-next-line no-var
  var game:
    | {
        dice?: { roll?: (formula: string) => Promise<unknown> | unknown };
        pf2e?: {
          actions?: {
            get?: (
              slug: string,
            ) => { use?: (options?: Record<string, unknown>) => unknown } | undefined;
            [slug: string]:
              | ((options?: Record<string, unknown>) => unknown)
              | { use?: (options?: Record<string, unknown>) => unknown }
              | undefined;
          };
        };
      }
    | undefined;
  // eslint-disable-next-line no-var
  var ChatMessage: { create?: (data: { content: string }) => Promise<unknown> | unknown } | undefined;
  // eslint-disable-next-line no-var
  var ui:
    | {
        notifications?: { warn?: (message: string) => void };
        chat?: {
          processMessage?: (
            content: string,
            options: Record<string, unknown>,
          ) => Promise<unknown> | unknown;
        };
      }
    | undefined;
  // eslint-disable-next-line no-var
  var canvas:
    | {
        tokens?: {
          controlled?: Array<{
            actor?: {
              increaseCondition?: (slug: string, options?: Record<string, unknown>) => unknown;
              toggleCondition?: (slug: string, options?: Record<string, unknown>) => unknown;
              addCondition?: (slug: string, options?: Record<string, unknown>) => unknown;
            };
          }>;
        };
      }
    | undefined;
  // eslint-disable-next-line no-var
  var CONFIG:
    | {
        PF2E?: {
          conditionTypes?: Record<string, unknown>;
          damageTypes?: Record<string, string>;
        };
      }
    | undefined;
}

describe("parseQuickRollInput", () => {
  beforeEach(() => {
    vi.restoreAllMocks();

    globalThis.game = {
      dice: {
        roll: vi.fn().mockResolvedValue(undefined),
      },
      pf2e: {
        actions: {
          get: vi.fn().mockReturnValue(undefined),
        },
      },
    };

    globalThis.ChatMessage = {
      create: vi.fn().mockResolvedValue(undefined),
    };

    globalThis.ui = {
      notifications: {
        warn: vi.fn(),
      },
      chat: {
        processMessage: vi.fn().mockResolvedValue(undefined),
      },
    };

    globalThis.canvas = {
      tokens: {
        controlled: [],
      },
    };

    globalThis.CONFIG = {
      PF2E: {
        damageTypes: Object.fromEntries([
          "acid", "bleed", "bludgeoning", "cold", "electricity", "fire", "force",
          "mental", "piercing", "poison", "slashing", "sonic", "spirit", "vitality", "void",
        ].map((type) => [type, type])),
        conditionTypes: {
          clumsy: {},
          prone: {},
          stunned: {},
        },
      },
    };
  });

  it("applies a condition when slash command is used", async () => {
    const increaseCondition = vi.fn().mockResolvedValue(undefined);
    globalThis.canvas = {
      tokens: {
        controlled: [{ actor: { increaseCondition } }],
      },
    };

    const result = await parseQuickRollInput("/prone");

    expect(result).toBe(true);
    expect(increaseCondition).toHaveBeenCalledWith("prone", undefined);
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("supports three-letter condition aliases with values", async () => {
    const increaseCondition = vi.fn().mockResolvedValue(undefined);
    globalThis.canvas = {
      tokens: {
        controlled: [{ actor: { increaseCondition } }],
      },
    };

    const result = await parseQuickRollInput("/clu 1");

    expect(result).toBe(true);
    expect(increaseCondition).toHaveBeenCalledWith("clumsy", { value: 1 });
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("warns when no token is selected for condition commands", async () => {
    const result = await parseQuickRollInput("/prone");

    expect(result).toBe(false);
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Bitte wähle einen Token aus, um eine Condition zu setzen.",
    );
  });

  it("rolls damage for shorthand damage type aliases", async () => {
    const result = await parseQuickRollInput("3d6+4 fir");

    expect(result).toBe(true);
    expect(globalThis.ui?.chat?.processMessage).toHaveBeenCalledWith("/r (3d6+4)[fire]", {});
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("rolls damage for vitality damage type aliases", async () => {
    const result = await parseQuickRollInput("2d6 vit");

    expect(result).toBe(true);
    expect(globalThis.ui?.chat?.processMessage).toHaveBeenCalledWith("/r (2d6)[vitality]", {});
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("rolls damage for void damage type aliases", async () => {
    const result = await parseQuickRollInput("1d8 void");

    expect(result).toBe(true);
    expect(globalThis.ui?.chat?.processMessage).toHaveBeenCalledWith("/r (1d8)[void]", {});
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("rolls damage for full damage type names with wrapped formulas", async () => {
    const result = await parseQuickRollInput("3d6+4 acid");

    expect(result).toBe(true);
    expect(globalThis.ui?.chat?.processMessage).toHaveBeenCalledWith("/r (3d6+4)[acid]", {});
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("creates a check chat card for explicit DC overrides", async () => {
    const result = await parseQuickRollInput("perc dc 19");

    expect(result).toBe(true);
    expect(globalThis.ChatMessage?.create).toHaveBeenCalledWith({
      content: "@Check[type:perception|dc:19]",
    });
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("derives check DCs from levels when no qualifier is provided", async () => {
    const result = await parseQuickRollInput("perc 11");

    expect(result).toBe(true);
    expect(globalThis.ChatMessage?.create).toHaveBeenCalledWith({
      content: "@Check[type:perception|dc:28]",
    });
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("supports level qualifiers for check DCs", async () => {
    const result = await parseQuickRollInput("fort lvl 3");

    expect(result).toBe(true);
    expect(globalThis.ChatMessage?.create).toHaveBeenCalledWith({
      content: "@Check[type:fortitude|dc:18]",
    });
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("warns when a requested level has no standard DC", async () => {
    const result = await parseQuickRollInput("perc level 30");

    expect(result).toBe(false);
    expect(globalThis.ChatMessage?.create).not.toHaveBeenCalled();
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Standard-DCs sind nur für Stufen 0–25 verfügbar.",
    );
  });

  it("warns when the damage type alias is unknown", async () => {
    const result = await parseQuickRollInput("2d6+4 xyz");

    expect(result).toBe(false);
    expect(globalThis.ui?.chat?.processMessage).not.toHaveBeenCalled();
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Unbekannte Schadensart 'xyz'.",
    );
  });

  it("rejects malformed check commands with punctuation", async () => {
    const result = await parseQuickRollInput("perc, 19");

    expect(result).toBe(false);
    expect(globalThis.ChatMessage?.create).not.toHaveBeenCalled();
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Check nicht erkannt. Verwende z.B. 'perc 20'.",
    );
  });

  it("fällt auf die Chat-Verarbeitung zurück, wenn game.dice.roll fehlt", async () => {
    globalThis.game = { dice: {} };

    const result = await parseQuickRollInput("3d6+4 acid");

    expect(result).toBe(true);
    expect(globalThis.ui?.chat?.processMessage).toHaveBeenCalledWith(
      "/r (3d6+4)[acid]",
      {},
    );
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("warnt, wenn weder game.dice.roll noch ui.chat.processMessage verfügbar sind", async () => {
    globalThis.game = { dice: {} };
    globalThis.ui = {
      notifications: {
        warn: vi.fn(),
      },
      chat: {},
    };

    const result = await parseQuickRollInput("2d6 fir");

    expect(result).toBe(false);
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Würfelmechanik nicht verfügbar.",
    );
  });

  it("invokes PF2e action macros when an action alias is provided", async () => {
    const useMock = vi.fn().mockResolvedValue(undefined);
    const getMock = vi.fn().mockReturnValue({ use: useMock });

    globalThis.game = {
      dice: {
        roll: vi.fn().mockResolvedValue(undefined),
      },
      pf2e: {
        actions: {
          get: getMock,
        },
      },
    };

    const result = await parseQuickRollInput("trip");

    expect(result).toBe(true);
    expect(getMock).toHaveBeenCalledWith("trip");
    expect(useMock).toHaveBeenCalledWith();
    expect(globalThis.ui?.notifications?.warn).not.toHaveBeenCalled();
  });

  it("warns when no matching action macro can be found", async () => {
    const getMock = vi.fn().mockReturnValue(undefined);

    globalThis.game = {
      dice: {
        roll: vi.fn().mockResolvedValue(undefined),
      },
      pf2e: {
        actions: {
          get: getMock,
        },
      },
    };

    const result = await parseQuickRollInput("tumble");

    expect(result).toBe(false);
    expect(getMock).toHaveBeenCalledWith("tumbleThrough");
    expect(globalThis.ui?.notifications?.warn).toHaveBeenCalledWith(
      "PF2e Quick Rolls: Aktion 'tumbleThrough' nicht verfügbar.",
    );
  });
});
