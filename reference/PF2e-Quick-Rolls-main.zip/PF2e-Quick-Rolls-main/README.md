# PF2e Quick Rolls

This repository contains the source code for the **PF2e Quick Rolls** Foundry VTT module. The project is structured for TypeScript development with a small build pipeline that outputs bundled code to the module directory expected by Foundry.

## Project layout

```
module/
  module.json        # Foundry manifest with module metadata
  packs/             # Placeholder for compendium packs
  lang/              # Localization files
  styles/            # CSS bundled with the module
  scripts/           # Bundled JavaScript output
  templates/         # Handlebars templates
src/                 # TypeScript source files
```

## Requirements

- Node.js 18+
- npm 9+

## Installation

1. Clone this repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Build the module bundle:
   ```bash
   npm run build
   ```

The compiled JavaScript will be emitted to `module/scripts`. Copy the entire `module/` directory into your Foundry VTT `Data/modules` folder (or symlink it during development). The module will appear in Foundry under the name **PF2e Quick Rolls**.

### Keybinding configuration

The module registers an action that opens the quick-roll prompt, but it is unbound by default. After enabling the module in Foundry, open **Configure Controls → PF2e Quick Rolls** and assign your preferred shortcut to **Open Quick Roll Prompt** before attempting to trigger it from the keyboard.

## Development

- **One-off build:**
  ```bash
  npm run build
  ```
- **Watch mode:**
  ```bash
  npm run dev
  ```
- **Run tests:**
  ```bash
  npm test
  ```

During development you can symlink the `module/` directory into your Foundry data path to test live changes. When using watch mode, tsup will rebuild the bundle whenever a file inside `src/` changes.

## Quick-roll prompt abbreviations

The quick-roll prompt accepts concise commands to trigger common checks and damage rolls. Use the following abbreviations when entering prompt text:

### Damage type aliases

| Eingabe | Vollständiger Schadens-Typ |
| --- | --- |
| `acid`, `aci` | Acid |
| `cold`, `col` | Cold |
| `electricity`, `ele`, `elec` | Electricity |
| `fire`, `fir` | Fire |
| `force` | Force |
| `sonic`, `son` | Sonic |
| `poison`, `poi` | Poison |
| `mental`, `men` | Mental |
| `negative`, `neg` | Negative |
| `positive`, `pos` | Positive |
| `vitality`, `vit` | Vitality |
| `void`, `voi` | Void |
| `bludgeoning`, `blu`, `blud` | Bludgeoning |
| `piercing`, `pie` | Piercing |
| `slashing`, `sla` | Slashing |

### Skill and save aliases

| Eingabe | Fertigkeit/Wurf |
| --- | --- |
| `acrobatics`, `acro` | Acrobatics |
| `arcana`, `arc` | Arcana |
| `athletics`, `ath` | Athletics |
| `crafting`, `cra` | Crafting |
| `deception`, `dec` | Deception |
| `diplomacy`, `dip` | Diplomacy |
| `intimidation`, `int` | Intimidation |
| `medicine`, `med` | Medicine |
| `nature`, `nat` | Nature |
| `occultism`, `occ` | Occultism |
| `perception`, `perc` | Perception |
| `performance`, `perf` | Performance |
| `religion`, `rel` | Religion |
| `society`, `soc` | Society |
| `stealth`, `ste` | Stealth |
| `survival`, `sur` | Survival |
| `thievery`, `thi` | Thievery |
| `fortitude`, `fort` | Fortitude Save |
| `reflex`, `ref` | Reflex Save |
| `will`, `wil` | Will Save |

### Action aliases

The prompt can also invoke PF2e system macros for common actions without opening their full sheets. Use one of the following keywords to trigger a macro directly:

| Eingabe | Aktion |
| --- | --- |
| `trip`, `tripup` | Trip |
| `disarm` | Disarm |
| `shove`, `push` | Shove |
| `grapple`, `grab` | Grapple |
| `escape` | Escape |
| `demoralize`, `demoralise` | Demoralize |
| `feint` | Feint |
| `aid` | Aid |
| `seek` | Seek |
| `recall`, `recallknowledge` | Recall Knowledge |
| `tumble`, `tumble through` | Tumble Through |

Example damage command: `2d6+4 fir` rolls fire damage. For checks you can either request a standard DC by level—`perc 11` or `perc lvl 11` create a Perception check against the level 11 standard DC of 28—or override the DC manually with `perc dc 20`.

### Condition slash commands

Wenn der Prompt mit `/` beginnt, wird ein Condition-Befehl für den aktuell ausgewählten Token erwartet.

- `/prone` setzt die Condition **prone**.
- `/clumsy 1` setzt **clumsy** auf Wert `1`.
- Die ersten drei Buchstaben reichen ebenfalls: `/clu 1`.

Hinweis: Es muss mindestens ein Token ausgewählt sein.
